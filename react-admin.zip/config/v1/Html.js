'use strict';
module.exports = {
    '/': {
        get: {
            file: 'index',
            html: true
        }
    }
};